<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.slimscroll.js"></script>
    <script src="js/select2.min.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>
    <script src="js/dataTables.bootstrap4.min.js"></script>
    <script src="js/moment.min.js"></script>
    <script src="js/Chart.bundle.js"></script> 
    <script src="js/chart.js"></script>
    <script src="plugins/summernote/dist/summernote-bs4.min.js"></script>
    <!-- <script src="js/jquery-ui.min.js"></script> -->
    <script src="js/fullcalendar.min.js"></script>
    <script src="js/jquery.fullcalendar.js"></script>
    <script src="plugins/light-gallery/js/lightgallery-all.min.js"></script>
    <script src="js/bootstrap-datetimepicker.min.js"></script>
    <script src="js/app.js"></script>
    <script>
            $(function () {
                $('#datetimepicker3').datetimepicker({
                    format: 'LT'
                });
        //         $(".doct").click(function() {
		// 	$(".doct").removeClass('active');
		// 	$(this).addClass('active');
		// });
            });
         </script><?php /**PATH C:\xampp\htdocs\preclinic_laravel\resources\views/layout/partials/footer-scripts.blade.php ENDPATH**/ ?>